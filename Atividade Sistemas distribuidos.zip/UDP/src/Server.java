import java.io.*;
import java.net.*;


public class Server {
    private static String[] quiz = {"VVVFF", "VVFVVF", "FVVF"};
    private static String[] result = {};

    private static int[] validAnswer(String correctAnswer, String answer){
        int hits = 0;
        int errors = 0;
        int[] r = new int[2];
        for(int i = 0; i < Integer.parseInt(result[1]); i++){
            if(correctAnswer.charAt(i) != answer.charAt(i))
                errors++;
            else
                hits++;
        }
        

        r[0] = hits;
        r[1] =  errors;
        return r;
    }
    public static void main(String[] args){
        
        DatagramSocket socket =  null;
        try{

            socket = new DatagramSocket(6789);
            byte[] buffer = new byte[1000];
            DatagramPacket req = null;
            String sr;
            int[] iResp = null;
            String sResp = null;
            byte[] bResp = null;
            DatagramPacket resp = null;
            
            while(true){
                System.out.println("*** Servidor aguardando!");

                req = new DatagramPacket(buffer, buffer.length);
                socket.receive(req);
                System.out.println("*** Request recebido de: " + req.getSocketAddress());
                sr = new String(req.getData());
                result = sr.split(";");
                iResp = validAnswer(quiz[Integer.parseInt(result[0])-1], result[2]);

                sResp = result[0]+";"+iResp[0]+";"+iResp[1];
                bResp = sResp.getBytes();

                resp = new DatagramPacket(bResp, sResp.length(), req.getAddress(), req.getPort());
                socket.send(resp);
                System.out.println("*** Resposta enviada para: " + req.getSocketAddress());
            }

        }catch (SocketException e) {
            System.out.println("Erro de socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Erro envio/recepcao pacote: " + e.getMessage());         
        }finally{
            if(socket != null) socket.close();
        }
    }
}
