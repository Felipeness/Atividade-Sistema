import java.io.*;
import java.net.*;

class ClienteThread implements Runnable{

    protected String server = "localhost";
    protected int port = 6789;
    protected String[] msg = {"1;1;1","1;1;1","1;1;1"};


    ClienteThread(String[] args){
        if (args.length > 0) server = args[0];
        if (args.length > 1) port = Integer.parseInt(args[1]);
        if (args.length > 2) msg[0] = args[2];
        if (args.length > 3) msg[1] = args[3];
        if (args.length > 4) msg[2] = args[4];
    }

    @Override
    public void run() {
        Thread thread = Thread.currentThread();
        DatagramSocket socket = null;
        
        try{
        	
        	socket = new DatagramSocket();
            System.out.println("* " + thread.getName() + " * Socket criado na porta: " + socket.getLocalPort());
            DatagramPacket req = null;
            DatagramPacket resp = null;
            String sResp = null;
            String[] vResp = null;
            byte[] buffer = null;
        	
        	for(int i = 0; i < 3; i++) {
                byte[] bMsg = msg[i].getBytes();
                InetAddress ipServer = InetAddress.getByName(server);
                
                req = new DatagramPacket(bMsg, msg[i].length(), ipServer, port);
                socket.send(req);
                System.out.println("* " + thread.getName() + " * Datagrama enviado: " + msg[i]);

                buffer = new byte[1000];
                resp = new DatagramPacket(buffer, buffer.length);
                socket.setSoTimeout(10000);
                socket.receive(resp);
                sResp = new String(resp.getData());
                vResp = sResp.split(";"); 
                System.out.println("* " + thread.getName() + " * Resposta do servidor: " + sResp);
                System.out.println("* " + thread.getName() + " * {\n   Quest�o "+vResp[0]+
                		"\n   Acertos: "+vResp[1]+" Erros: "+vResp[2]+"\n}");
        	}
            

        } catch (SocketException e) {
            System.out.println("* " + thread.getName() + " * Erro socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("* " + thread.getName() + " * Erro envio/recepcao do pacote: " + e.getMessage());
        }finally{
            if (socket != null) socket.close();
        }
        
    }

}

public class Cliente {
    public static void main(String[] args){
        String[] argsAluno1 = {"127.0.0.1", "6789", "1;5;VVFVV", "2;6;VFFVVV", "3;4;VFFV"};
        String[] argsAluno2 = {"127.0.0.1", "6789", "1;5;VVFFF", "2;5;FVVFVV", "3;4;VFVF"};

        Thread cliente1 = new Thread(new ClienteThread(argsAluno1), "Aluno 1");
        Thread cliente2 = new Thread(new ClienteThread(argsAluno2), "Aluno 2");
        cliente1.start();
        cliente2.start();
    }
}
